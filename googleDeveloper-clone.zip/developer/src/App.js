import React, { useState } from 'react'
import 'bootstrap/dist/css/bootstrap.min.css';
import Navbar from './components/Navbar';
import Buttons from './components/Buttons';
import Slider from './components/Slider';
import Footer from './components/Footer';
import Img from './components/Img';
import Icons from './components/Icons';
import Image from './components/Image';
import Image2 from './components/Image2';
import Image3 from './components/Image3';
import DownNav from './components/DownNav';
const App = () => {
  
  return (
    <div>
    <Navbar/>
    <Buttons/>
    <Icons/>
    <Slider/>
    <Img/>
    <Image/>
    <Image2/>
    <Image3/>
    <Footer/>
    <DownNav/>
    </div>
  )
}

export default App




