import React, { useState } from "react";
import Container from "react-bootstrap/Container";
import Nav from "react-bootstrap/Nav";
import Navbar from "react-bootstrap/Navbar";
import NavDropdown from "react-bootstrap/NavDropdown";
import { BsSearch, BsPersonFill } from "react-icons/bs";
import './navbar.css';
import { FaGlobe } from 'react-icons/fa';

const Navbarr = () => {
  const [productsDropdownOpen, setProductsDropdownOpen] = useState(false);
  const [communityDropdownOpen, setCommunityDropdownOpen] = useState(false);
  const [isSearchFocused, setIsSearchFocused] = useState(false);

  const handleProductsDropdownToggle = () => {
    setProductsDropdownOpen(!productsDropdownOpen);
  };

  const handleCommunityDropdownToggle = () => {
    setCommunityDropdownOpen(!communityDropdownOpen);
  };

  const handleSearchFocus = () => {
    setIsSearchFocused(true);
  };

  const handleSearchBlur = () => {
    setIsSearchFocused(false);
  };

  return (
    <>
    <Navbar expand="md" className="bg-white fixed-top border">
      <Navbar.Brand href="#">
        <img
          src="https://www.gstatic.com/devrel-devsite/prod/v01480ab0f36db59e4033b3554acd76a679317609de08cca4b3664f0498a344aa/developers/images/lockup-new.svg"
          alt="Google"
          height="40"
          width="auto"
          style={{ marginLeft: '10px' }}
        />
      </Navbar.Brand>
      <Navbar.Toggle aria-controls="basic-navbar-nav" />
      <Navbar.Collapse id="basic-navbar-nav">
        <Nav className="me-auto d-flex align-items-center" >
          
           
           <NavDropdown title="Products" id="products-dropdown" show={productsDropdownOpen} onMouseEnter={handleProductsDropdownToggle} onMouseLeave={handleProductsDropdownToggle} drop="down" className="nav-link-style">
  <div style={{ display: 'flex' }}>
    <div style={{ flex: 1 }}>
      <NavDropdown.Item href="#product1" style={{ fontWeight: 'bold' }}>Develop</NavDropdown.Item>
      <div style={{ fontSize: '20px', marginTop: '10px' }}>
        <NavDropdown.Item href="#product2">Android</NavDropdown.Item>
        <NavDropdown.Item href="#product2">ChromeOS</NavDropdown.Item>
        <NavDropdown.Item href="#product2">Cloud</NavDropdown.Item>
        <NavDropdown.Item href="#product2">Firebase</NavDropdown.Item>
        <NavDropdown.Item href="#product2">Flutter</NavDropdown.Item>
        <NavDropdown.Item href="#product2">Google Assistant</NavDropdown.Item>
        <NavDropdown.Item href="#product2">Google Maps Platform</NavDropdown.Item>
        <NavDropdown.Item href="#product2">Google Workspace</NavDropdown.Item>
        <NavDropdown.Item href="#product2">TensorFlow</NavDropdown.Item>
        <NavDropdown.Item href="#product2">Web</NavDropdown.Item>
        <NavDropdown.Item href="#product2">Youtube</NavDropdown.Item>
      </div>
    </div>
    <div style={{ flex: 1 }}>
      <NavDropdown.Item href="#product1" style={{ fontWeight: 'bold' , marginLeft:'50px' }}>Grow</NavDropdown.Item>
      <div style={{ fontSize: '20px', marginTop: '10px' , marginLeft:'50px' }}>
        <NavDropdown.Item href="#product2">Firebase</NavDropdown.Item>
        <NavDropdown.Item href="#product2">Google Ads</NavDropdown.Item>
        <NavDropdown.Item href="#product2">Google Analytics</NavDropdown.Item>
        <NavDropdown.Item href="#product2">Google Play</NavDropdown.Item>
        <NavDropdown.Item href="#product2">Search</NavDropdown.Item>
        <NavDropdown.Item href="#product2">Web Push and Notification APIs</NavDropdown.Item>
      </div>
      
    </div>
    <div style={{ flex: 1 }}>
      <NavDropdown.Item href="#product1" style={{ fontWeight: 'bold' , marginLeft:'50px' }}>Earn</NavDropdown.Item>
      <div style={{ fontSize: '20px', marginTop: '10px' , marginLeft:'50px' }}>
        <NavDropdown.Item href="#product2">AdMob</NavDropdown.Item>
        <NavDropdown.Item href="#product2">Google Ads API</NavDropdown.Item>
        <NavDropdown.Item href="#product2">Google Pay</NavDropdown.Item>
        <NavDropdown.Item href="#product2">Google Play Billing</NavDropdown.Item>
        <NavDropdown.Item href="#product2">Interactive Media Ads</NavDropdown.Item>
      </div>
      
    </div>
  </div>
</NavDropdown>

            
            
          
          <Nav.Link href="#link" className="nav-link-style">
            Solutions
          </Nav.Link>
          <Nav.Link href="#link" className="nav-link-style">
            Events
          </Nav.Link>
          <Nav.Link href="#link" className="nav-link-style">
            Learn
          </Nav.Link>
          
<NavDropdown
  title="Community"
  id="community-dropdown"
  show={communityDropdownOpen}
  onMouseEnter={handleCommunityDropdownToggle}
  onMouseLeave={handleCommunityDropdownToggle}
  drop="down"
  className="nav-link-style"
>
  <div style={{ display: 'flex' }}>
    <div style={{ flex: 1 }}>
      <NavDropdown.Item href="#community1" style={{ fontWeight: 'bold' }}>Groups</NavDropdown.Item>
      <div style={{ fontSize: '20px', marginTop: '5px' }}>
        <NavDropdown.Item href="#community2">Google Developer Groups</NavDropdown.Item>
        <NavDropdown.Item href="#community2">Google Developer Student Clubs</NavDropdown.Item>
        <NavDropdown.Item href="#community2">Women Techmakers</NavDropdown.Item>
        <NavDropdown.Item href="#community2">Google Developer Experts</NavDropdown.Item>
        <NavDropdown.Item href="#community2">Tech Equity Collective</NavDropdown.Item>
      </div>
    </div>
    <div style={{ flex: 1 }}>
      <NavDropdown.Item href="#community1" style={{ fontWeight: 'bold' }}>Programs</NavDropdown.Item>
      <div style={{ fontSize: '20px', marginTop: '5px' }}>
        <NavDropdown.Item href="#community2">Accelerator</NavDropdown.Item>
        <NavDropdown.Item href="#community2">Solution Challenge</NavDropdown.Item>
        <NavDropdown.Item href="#community2">DevFest</NavDropdown.Item>
      </div>
    </div>
    <div style={{ flex: 1 }}>
      <NavDropdown.Item href="#community1" style={{ fontWeight: 'bold' }}>Stories</NavDropdown.Item>
      <div style={{ fontSize: '20px', marginTop: '5px' }}>
        <NavDropdown.Item href="#community2">All Stories</NavDropdown.Item>
      </div>
    </div>
  </div>
</NavDropdown>



          <Nav.Link href="#link" className="nav-link-style">
            Developer Profile
          </Nav.Link>
          <Nav.Link href="#link" className="nav-link-style">
            Blog
          </Nav.Link>
        </Nav>
        <div className={`search-container ${isSearchFocused ? 'expanded-search' : ''}`}>
          <div className="input-group">
            <input
              type="text"
              className="form-control"
              placeholder="Search"
              onFocus={handleSearchFocus}
              onBlur={handleSearchBlur}
            />
            <button type="button" className="btn btn-outline-primary" >
              < BsSearch />
            </button>
          </div>
        </div>
        <NavDropdown
          title={<span><FaGlobe className="earth-icon" style={{fontSize:'30px'}} /> English</span>}
          id="basic-nav-dropdown"
          className="nav-dropdown-title"
          style={{marginLeft:'30px'}}
        >
          <NavDropdown.Item href="#action/3.1">English</NavDropdown.Item>
          <NavDropdown.Item href="#action/3.1">English</NavDropdown.Item>
            <NavDropdown.Item href="#action/3.2">
              Bahasa Indonesia
            </NavDropdown.Item>
            <NavDropdown.Item href="#action/3.3">Deutsch</NavDropdown.Item>
            <NavDropdown.Item href="#action/3.3">Español</NavDropdown.Item>
            <NavDropdown.Item href="#action/3.3">Français</NavDropdown.Item>
        </NavDropdown>
        
        <div>
          <button type="button" className="btn btn-primary btn-danger" style={{marginLeft:'40px' , marginRight:'5px'}}>
            <BsPersonFill />
          </button>
        </div>
       
      </Navbar.Collapse>
  </Navbar>
      

      <div style={{ marginTop: '50px', display: 'flex', alignItems: 'left' }}>
  <div style={{ maxWidth: '50%',  padding: '0 20px' }}>
    <h1 style={{ fontWeight: 'bolder', fontSize: '120px', marginBottom: '20px' }}>
      Build smarter, ship faster
    </h1>
    <h2 style={{ lineHeight: '1.5' }}>
      Unlock creativity and simplify your workflow with open,
      integrated solutions.
    </h2>
  </div>
  <div style={{ flex: '1', padding: '0 20px' }}>
    <video
      loop
      autoPlay
      muted
      src="https://developers.google.com/static/homepage-assets/images/build-smarter.mp4"
      style={{ border: 0, height: 'auto', width: '90%' }}
    ></video>
  </div>
</div>



    </>
  );
};

export default Navbarr;
