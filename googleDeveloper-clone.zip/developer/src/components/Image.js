import React from 'react';

const Image = () => {
  return (
    <div>
      <div style={{ display: 'flex', alignItems: 'center', margin: '30px', borderRadius: '10px', padding: '40px' }}>
        <div style={{ width: '50%', height: '400px' }}>
          <img
            src="https://developers.google.com/static/homepage-assets/images/explore-your-interests_856.jpg"
            alt=""
            style={{ border: '0', height: 'auto', maxWidth: '100%', borderRadius: '5px' }}
          />
        </div>
        <div style={{ flex: 1, marginLeft: '20px' }}>
          <img src='https://developers.google.com/static/homepage-assets/images/explore-interests-eyebrow.svg' alt="Explore Interests" />
          <p style={{ fontWeight: 'bolder', fontSize: '50px' }}>Find an event</p>
          <p style={{ fontSize: '30px' }}>Grow your knowledge through online and in-person developer events.</p>
          <button className="btn btn-secondary btn-lg mt-4" style={{ fontWeight: 'bold', backgroundColor: 'white', color: 'blue' }}>View events</button>
        </div>
      </div>
    </div>
  );
};

export default Image;
