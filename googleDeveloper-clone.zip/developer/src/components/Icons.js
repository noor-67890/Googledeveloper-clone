import React from 'react';
import { Card } from 'react-bootstrap';

const Icons = () => {
  const cardData = [
    {
      imageSrc: 'https://developer.android.com/images/brand/Android_Robot.png',
      title: 'Android',
      description: 'Modern tools to help you build experiences that people love across every Android device',
    },
    {
      imageSrc: 'https://www.gstatic.com/images/branding/product/2x/google_cloud_64dp.png',
      title: 'Google Cloud',
      description: 'Build apps faster, make smarter business decisions, and connect people everywhere.',
    },
    {
      imageSrc: 'https://developers.google.com/static/site-assets/images/products/tensorflow-logo-196.png',
      title: 'TensorFlow',
      description: 'An end-to-end platform that makes it easy to build and deploy ML models in any environment.',
    },
    {
      imageSrc: 'https://developers.google.com/static/homepage-assets/images/chromeos-logo.svg',
      title: 'Google Chrome',
      description: 'Modern tools and features that help you build high quality web experiences.',
    },
    {
      imageSrc: 'https://www.gstatic.com/images/branding/product/2x/play_prism_64dp.png',
      title: 'Google Play',
      description: 'Grow your business, improve app quality, engage your audience, and earn revenue.',
    },
    {
      imageSrc: 'https://www.gstatic.com/images/branding/product/2x/firebase_64dp.png',
      title: 'Firebase',
      description: 'An app development platform that helps you build and grow apps and games users love',
    },
    {
      imageSrc: 'https://developers.google.com/static/focus/images/palm-logo.svg',
      title: 'PaLM',
      description: 'An easy and safe API to experiment with Googles large language models.',
    },
    {
      imageSrc: 'https://developers.google.com/static/focus/images/makersuite.png',
      title: 'MakerSuite',
      description: 'Quickly prototype generative AI applications in a browser - no ML expertise or coding required.',
    },
    {
      imageSrc: 'https://www.gstatic.com/images/branding/product/2x/flutter_64dp.png',
      title: 'Flutter',
      description: 'Build, test, and deploy beautiful web, mobile, desktop and embedded apps from one codebase.',
    },
    {
      imageSrc: 'https://developers.google.com/static/homepage-assets/images/google-ads.svg',
      title: 'Flutter',
      description: 'Promote your website, products, and app to the right users with Google Ads.'      ,
    },
    {
      imageSrc: 'https://developers.google.com/static/focus/images/kaggle.svg',
      title: 'Kaggle',
      description: 'A platform to share machine learning data sets, explore and build models, and compete in competitions.     ',
    },
    {
      imageSrc: 'https://developers.google.com/static/homepage-assets/images/angular.png',
      title: 'Angular',
      description: 'The web development framework for building the future.',
    },
   
    
  ];

  return (
    <div>
      <h1 className="text-center font-weight-bold mt-5" style={{ fontSize: '50px', fontWeight: 'bolder' }}>Featured products</h1>
      <div className="mt-4 d-flex flex-wrap justify-content-between align-items-start" style={{ margin: '50px' }}>
        {cardData.map((card, index) => (
          <div key={index} className="d-flex flex-column align-items-center mb-4" style={{ maxWidth: '300px', flex: '0 0 calc(25% - 40px)',  margin: '20px' }}>
            <Card className="border-secondary p-5 rounded d-flex flex-column align-items-center justify-content-between" style={{ width: '400px', height: '300px', borderWidth: '1px', borderColor: 'grey' }}>
              <img
                src={card.imageSrc}
                alt="nothing"
                className="mb-3 rounded-circle"
                style={{ width: '80px', height: '80px', objectFit: 'cover' }}
              />
              <div className="text-center">
                <p className="font-weight-bold" style={{ fontSize: '40px', fontWeight: 'bolder' }}>{card.title}</p>
                <p className="mb-0" style={{ fontSize: '16px' , marginBottom:'5px' }}>{card.description}</p>
              </div>
            </Card>
          </div>
        ))}
      </div>
      <div className="text-center mt-4">
        <button className="btn btn-primary btn-lg p-3" style={{ fontWeight: 'bold', backgroundColor: 'blue', color: 'white' }}>View all developers products</button>
      </div>
    </div>
  );
};

export default Icons;
