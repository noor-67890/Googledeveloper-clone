import React from 'react';

const Image2 = () => {
  return (
    <div>
      <div style={{ display: 'flex', alignItems: 'center', margin: '30px', borderRadius: '10px', padding: '40px' }}>
        <div style={{ flex: 1, marginLeft: '20px' }}>
          <img src='https://developers.google.com/static/homepage-assets/images/technical-skills-eyebrow.svg' alt="" style={{ border: 0, height: '150px', maxWidth: '100%' }} />
          <p style={{ fontWeight: 'bolder', fontSize: '50px' }}>Improve technical skills</p>
          <p style={{ fontSize: '30px' }}>Keep up with Google technology. Sharpen skills and master new ones.</p>
          <button className="btn btn-secondary btn-lg mt-4" style={{ fontWeight: 'bold', backgroundColor: 'white', color: 'blue' }}>Start learning</button>
        </div>
        <img
          src="https://developers.google.com/static/homepage-assets/images/technical-skills_856.jpg"
          alt=""
          style={{ width: '50%', borderRadius: '5px', border: 0, height: 'auto', maxWidth: '100%' }}
        />
      </div>
    </div>
  );
}

export default Image2;
