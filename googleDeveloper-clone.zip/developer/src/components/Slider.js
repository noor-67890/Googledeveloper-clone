import React, { useState } from 'react';
import { Carousel } from 'react-bootstrap';
import './navbar.css';

const Slider = () => {
  const [index, setIndex] = useState(0);

  const handleSelect = (selectedIndex) => {
    setIndex(selectedIndex);
  };

  return (
    <div className="slider-container">
      <Carousel activeIndex={index} onSelect={handleSelect}>
      <Carousel.Item>
         
      <div style={{ display: 'flex', alignItems: 'center', margin: '30px', borderRadius: '10px', padding: '40px' }}>
        <div style={{ flex: 1, marginLeft: '20px' }}>
         <p>TRENDING NEWS</p>
          <h3 style={{ fontWeight: 'bolder', fontSize: '50px' }}>Funding to help small studios grow on Google Play</h3>
          <p style={{ fontSize: '20px' }}>The Indie Games Fund offers gaming devs in Latin America cash and equity-free support.</p>
          <button className="btn btn-primary btn-lg mt-4" style={{ fontWeight: 'bold', backgroundColor: 'blue', color: 'white' }}>Learn more</button>
        </div>
        <img
          src="https://developers.google.com/static/focus/images/indie-games.jpg"
          alt=""
          style={{ width: '50%', borderRadius: '5px', height: '400px', maxWidth: '100%' , borderRadius: '10px'}}
        />
      </div>
       </Carousel.Item>
       <Carousel.Item>
         
      <div style={{ display: 'flex', alignItems: 'center', margin: '20px', borderRadius: '10px', padding: '30px' }}>
        <div style={{ flex: 1, marginLeft: '20px' }}>
         <p>TRENDING NEWS</p>
          <h3 style={{ fontWeight: 'bolder', fontSize: '50px' }}>
                    Ship faster with Chrome for Testing</h3>
          <p style={{ fontSize: '20px' }}>Avoid development issues from browser auto-updates with the latest from Chrome.</p>
          <button className="btn btn-primary btn-lg mt-4" style={{ fontWeight: 'bold', backgroundColor: 'blue', color: 'white' }}>Learn more</button>
        </div>
        <img
          src="https://developers.google.com/static/homepage-assets/images/ship-faster.svg"
          alt=""
          style={{ width: '50%', borderRadius: '5px',  height: '400px', borderRadius: '10px'}}
        />
      </div>
       </Carousel.Item>
       <Carousel.Item>
         
      <div style={{ display: 'flex', alignItems: 'center', margin: '20px', borderRadius: '10px', padding: '30px' }}>
        <div style={{ flex: 1, marginLeft: '20px' }}>
         <p>TRENDING NEWS</p>
          <h3 style={{ fontWeight: 'bolder', fontSize: '50px' }}>
          Go cross-platform with Google Play Games for PC</h3>
          <p style={{ fontSize: '20px' }}>Provide a seamless gaming experience across mobile and web with Play Games Services (PGS) v2.</p>
          <button className="btn btn-primary btn-lg mt-4" style={{ fontWeight: 'bold', backgroundColor: 'blue', color: 'white' }}>Learn more</button>
        </div>
        <img
          src="https://developers.google.com/static/homepage-assets/images/google-play-games.png"
          alt=""
          style={{ width: '65%', borderRadius: '5px',  height: '450px', borderRadius: '10px'}}
        />
      </div>
       </Carousel.Item>
       
       <Carousel.Item>
         
      <div style={{ display: 'flex', alignItems: 'center', margin: '20px', borderRadius: '10px', padding: '30px' }}>
        <div style={{ flex: 1, marginLeft: '20px' }}>
         <p>TRENDING NEWS</p>
          <h3 style={{ fontWeight: 'bolder', fontSize: '50px' }}>
          Explore the new, experimental Project IDX</h3>
          <p style={{ fontSize: '20px' }}>An initiative to bring your full-stack, multiplatform app development workflow to the cloud.</p>
          <button className="btn btn-primary btn-lg mt-4" style={{ fontWeight: 'bold', backgroundColor: 'blue', color: 'white' }}>Learn more</button>
        </div>
        <img
          src="https://developers.google.com/static/homepage-assets/images/idx.png"
          alt=""
          style={{ width: '60%', borderRadius: '5px',  height: '450px', borderRadius: '10px'}}
        />
      </div>
       </Carousel.Item>
       <Carousel.Item>
         
      <div style={{ display: 'flex', alignItems: 'center', margin: '20px', borderRadius: '10px', padding: '30px' }}>
        <div style={{ flex: 1, marginLeft: '20px' }}>
         <p>TRENDING NEWS</p>
          <h3 style={{ fontWeight: 'bolder', fontSize: '50px' }}>
          Optimize for large screens with these APIs and tools</h3>
          <p style={{ fontSize: '20px' }}>Ensure users have a good experience with your app on the new Pixel Fold and Pixel Tablet.</p>
          <button className="btn btn-primary btn-lg mt-4" style={{ fontWeight: 'bold', backgroundColor: 'blue', color: 'white' }}>Learn more</button>
        </div>
        <img
          src="https://developers.google.com/static/focus/images/optimizing-large-screen.png"
          alt=""
          style={{ width: '60%', borderRadius: '5px',  height: '450px', borderRadius: '10px'}}
        />
      </div>
       </Carousel.Item>
     
      
         {/* Navigation arrows */}
         <div className="carousel-controls">
          <a
            className="carousel-control-prev"
            href="#"
            role="button"
            data-slide="prev"
            onClick={() => handleSelect(index - 1)}
          >
            <span className="carousel-control-prev-icon" aria-hidden="true" />
            <span className="sr-only">Previous</span>
          </a>
          <a
            className="carousel-control-next"
            href="#"
            role="button"
            data-slide="next"
            onClick={() => handleSelect(index + 1)}
          >
            <span className="carousel-control-next-icon" aria-hidden="true" />
            <span className="sr-only">Next</span>
          </a>
        </div>
      </Carousel>
    </div>
  );
};

export default Slider;
