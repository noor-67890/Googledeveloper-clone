import React from 'react';

const Img = () => {
  return (
    <div style={{ backgroundColor: '#f4f4f4', padding: '40px', marginTop: '50px' }}>
      <div style={{ display: 'flex', alignItems: 'center' }}>
        <img
          src='https://developers.google.com/static/focus/images/giraffe_856.png'
          alt='image1'
          style={{
            borderRadius: '10px',
            width: '700px',
            height: '450px',
            margin: '20px',
          }}
        />
        <div>
          <h5>WHAT'S NEW IN ANDROID</h5>
          <p style={{ fontWeight: 'bolder', fontSize: '50px' }}>Android Studio Giraffe is now stable</p>
          <p style={{ fontSize: '30px' }}>Featuring updates to Live Edit, Compose animation previews, a new Device Explorer, and more.</p>
          <button className="btn btn-primary btn-lg mt-4" style={{ fontWeight: 'bold', backgroundColor: 'blue', color: 'white' }}>Download now</button>
        </div>
      </div>
      <div >
        
      </div>
     
    </div>
    
  );
};

export default Img;
