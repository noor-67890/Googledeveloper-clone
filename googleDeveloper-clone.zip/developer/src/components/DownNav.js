import React, { useState } from "react";
import { Row, Col, NavDropdown } from "react-bootstrap";
import { FaGlobe } from "react-icons/fa";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import './navbar.css';

const DownNav = () => {
  const [showDropdown, setShowDropdown] = useState(false);

  // Settings for the slider
  const sliderSettings = {
    dots: false,
    infinite: false,
    speed: 500,
    slidesToShow: 6,
    slidesToScroll: 1,
    vertical: true,
    verticalSwiping: true,
  };

  return (
    <div>
      <Row className="align-items-center" style={{ margin: "0" }}>
        <Col xs="auto">
          <img
            src="https://www.gstatic.com/devrel-devsite/prod/ved0354e60ebc2a2191daafd73d0c0dc1e5fda3e6da9d7c8803612e4e80917ef9/developers/images/lockup-google-for-developers.svg"
            alt="Google for Developers"
            style={{ width: "200px", height: "50px" }}
          />
        </Col>
        <Col>
          <ul className="list-unstyled d-flex">
            <li style={{ fontSize: "18px" }}>Android</li>
            <li style={{ fontSize: "18px", marginLeft: "20px" }}>Chrome</li>
            <li style={{ fontSize: "18px", marginLeft: "20px" }}>Firebase</li>
            <li style={{ fontSize: "18px", marginLeft: "20px" }}>
              Google Cloud Platform
            </li>
            <li style={{ fontSize: "18px", marginLeft: "20px" }}>
              All products
            </li>
          </ul>
        </Col>
      </Row>
      <hr />
      <div
        style={{
          display: "flex",
          flexDirection: "row",
          alignItems: "center",
          margin: "20px",
        }}
      >
        <h5 style={{ marginTop: "20px", marginRight: "20px" }}>
          Terms | Privacy
        </h5>
        <p style={{ marginTop: "20px", marginLeft: "auto" }}>
          Sign up for the Google for Developers newsletter
        </p>
        <button
          className="btn btn-secondary btn-lg"
          style={{
            fontWeight: "bold",
            backgroundColor: "blue",
            color: "white",
            marginLeft: "10px",
            height: "50px",
            borderRadius: "4px",
          }}
        >
          Subscribe
        </button>
        <NavDropdown
          title={
            <span>
              <FaGlobe className="earth-icon" /> English
            </span>
          }
          id="basic-nav-dropdown"
          className={`nav-dropdown-title nav-dropdown-container ${showDropdown ? "show" : ""}`}
          style={{ marginLeft: "10px", borderRadius: "4px" }}
          onMouseEnter={() => setShowDropdown(true)}
          onMouseLeave={() => setShowDropdown(false)}
        >
          <Slider
            {...sliderSettings}
            className={`animated-dropdown ${showDropdown ? "show" : ""} slider-dropdown`}
          >
            <NavDropdown.Item href="#action/3.1">English</NavDropdown.Item>
            <NavDropdown.Item href="#action/3.2">
              Bahasa Indonesia
            </NavDropdown.Item>
            <NavDropdown.Item href="#action/3.3">Deutsch</NavDropdown.Item>
            <NavDropdown.Item href="#action/3.3">Español</NavDropdown.Item>
            <NavDropdown.Item href="#action/3.3">Français</NavDropdown.Item>
            <NavDropdown.Item href="#action/3.3">Italiano</NavDropdown.Item>
            <NavDropdown.Item href="#action/3.3">Polski</NavDropdown.Item>
            <NavDropdown.Item href="#action/3.3">
              Português – Brasil
            </NavDropdown.Item>
            <NavDropdown.Item href="#action/3.3">Tiếng Việt</NavDropdown.Item>
            <NavDropdown.Item href="#action/3.3">Türkçe</NavDropdown.Item>
            <NavDropdown.Item href="#action/3.3">Русский</NavDropdown.Item>
            <NavDropdown.Item href="#action/3.3">العربيّة</NavDropdown.Item>
            <NavDropdown.Item href="#action/3.3">فارسی</NavDropdown.Item>
            <NavDropdown.Item href="#action/3.3">हिंदी</NavDropdown.Item>
            <NavDropdown.Item href="#action/3.3">বাংলা</NavDropdown.Item>
            <NavDropdown.Item href="#action/3.3">ภาษาไทย</NavDropdown.Item>
            <NavDropdown.Item href="#action/3.3">中文 – 简体</NavDropdown.Item>
            <NavDropdown.Item href="#action/3.3">中文 – 繁體</NavDropdown.Item>
            <NavDropdown.Item href="#action/3.3">日本語</NavDropdown.Item>
            <NavDropdown.Item href="#action/3.3">한국어</NavDropdown.Item>
          </Slider>
        </NavDropdown>
      </div>
    </div>
  );
};

export default DownNav;
