import React from 'react'

const Image3 = () => {
  return (
    <div>
      <div style={{ display: 'flex', alignItems: 'center', margin: '30px', borderRadius: '10px',  padding: '40px' }}>
      <img
        src="https://developers.google.com/static/homepage-assets/images/find-community_856.png"
        alt=""
        style={{ width: '50%', borderRadius: '5px' }}
      />
      <div style={{ flex: 1, marginLeft: '20px' }}>
        <img src='https://developers.google.com/static/homepage-assets/images/find-community-eyebrow.svg'
        style={{height: '150px' , margin:'auto'}}
        ></img>
        <p style={{ fontWeight: 'bolder', fontSize: '50px' }}>Join a community</p>
        <p style={{ fontSize: '30px' }}>Meet a diverse network, no matter where you are on your developer journey.
</p>
        <button className="btn btn-secondary btn-lg mt-4" style={{ fontWeight: 'bold', backgroundColor: 'white', color: 'blue' }}>Explore communities</button>
      </div>
    </div>
    </div>
  )
}

export default Image3;
