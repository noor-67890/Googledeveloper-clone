import React from 'react';
import './navbar.css';
const Footer = () => {
  return (
    <div>
      <div>
        <footer>
          <div>
            <hr className="d-md-block" />
            <section className="">
              <div className="row">
                <div className="col-md-3 col-lg-3 col-xl-3 mt-4 ml-4">
                  <ul className="list-unstyled">
                    <li style={{ fontSize: '20px', marginTop:'10px', marginLeft:'40px'  }}>Connect</li>
                    <li style={{ fontSize: '18px', marginTop:'10px', marginLeft:'40px'}}>Blog</li>
                    <li style={{ fontSize: '18px', marginTop:'10px', marginLeft:'40px' }}>Instagram</li>
                    <li style={{ fontSize: '18px', marginTop:'10px', marginLeft:'40px' }}>LinkedIn</li>
                    <li style={{ fontSize: '18px', marginTop:'10px', marginLeft:'40px' }}>Twitter</li>
                    <li style={{ fontSize: '18px' , marginTop:'10px', marginLeft:'40px'}}>YouTube</li>
                  </ul>
                </div>
                <div className="col-md-3 col-lg-3 col-xl-3 mx-auto mt-4">
                  <ul className="list-unstyled mt-2">
                    <li style={{ fontSize: '20px' }}>Programs</li>
                    <li style={{ fontSize: '18px', marginTop:'10px' }}>Women Techmakers</li>
                    <li style={{ fontSize: '18px', marginTop:'10px' }}>Google Developer Groups</li>
                    <li style={{ fontSize: '18px' , marginTop:'10px' }}>Google Developer Experts</li>
                    <li style={{ fontSize: '18px', marginTop:'10px' }}>Accelerators</li>
                    <li style={{ fontSize: '18px', marginTop:'10px' }}>Google Developer Student Clubs</li>
                  </ul>
                </div>
                <div className="col-md-3 col-lg-3 col-xl-3 mx-auto mt-4">
                  <ul className="list-unstyled mt-2">
                    <li style={{ fontSize: '20px', marginTop:'10px' }}>Developer consoles</li>
                    <li style={{ fontSize: '18px', marginTop:'10px' }}>Google API Console</li>
                    <li style={{ fontSize: '18px', marginTop:'10px' }}>Google Cloud Platform Console</li>
                    <li style={{ fontSize: '18px', marginTop:'10px' }}>Google Play Console</li>
                    <li style={{ fontSize: '18px', marginTop:'10px' }}>Firebase Console</li>
                    <li style={{ fontSize: '18px', marginTop:'10px' }}>Actions on Google Console</li>
                    <li style={{ fontSize: '18px', marginTop:'10px' }}>Cast SDK Developer Console</li>
                    <li style={{ fontSize: '18px', marginTop:'10px' }}>Chrome Web Store Dashboard</li>
                  </ul>
                </div>
              </div>
              <hr />
            </section>
          </div>
          
          
        </footer>
      </div>
    </div>
  );
};

export default Footer;
