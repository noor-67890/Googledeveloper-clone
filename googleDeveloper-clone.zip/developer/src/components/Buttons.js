import React from 'react';
import Button from 'react-bootstrap/Button';
import { FaArrowRight } from 'react-icons/fa';

const Buttons = () => {
  const buttonsData = ['Mobile', 'Web', 'AI', 'Cloud'];

  return (
    <div className="mt-3 text-bold text-center" style={{ display: 'flex' , alignitem:"right"}}>
      <h2 style={{ margin: '10px', fontWeight: 'bold', }}>
        I'm building for:
      </h2>
      <div className="d-flex justify-content-center pe-2">
        {buttonsData.map((label, index) => (
          <Button
            key={index}
            variant="outline-dark"
            className="me-2 mb-2"
            style={{
              padding: '10px',
              fontFamily: "'Google Sans', sans-serif",
              color: 'blue',
              fontSize: '20px',
              width: '100px',
              height: '40px',
              margin: '10px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            {label}
            <FaArrowRight className="ms-1" />
          </Button>
        ))}
      </div>
    </div>
  );
};

export default Buttons;
